const http = require('http')
const express = require('express')
const fs = require('fs')
const bodyParser = require('body-parser')  
const path = require('path')

let app = express()

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))
app.use(express.static(path.join(__dirname, 'public')))
app.use(bodyParser.urlencoded({ extended: true }))

function LeggiJson(path){
    try {
        const punti = fs.readFileSync(path);
        return JSON.parse(punti);
    } catch (err) {
        console.error('Errore nella lettura del file JSON:', err);
        return [];
    }
}
app.get('/', (req, res) =>{
    res.render('index')
});

app.get('/mappa', (req, res) => {
    const punti = LeggiJson('punti.json')
    const puntiDaCollegare = LeggiJson('puntiDaCollegare.json')
    //console.log(punti);  // Verifica che i dati siano corretti
    //console.log(puntiDaCollegare);  // Verifica che i dati siano corretti
    res.render('mappa', { punti: punti, puntiDaCollegare: puntiDaCollegare })  // Renderizza 'views/mappa.ejs' con l'oggetto punti
});

const server = http.createServer(app);

server.listen(8080, "127.0.0.1", function(){
    console.log("Server attivo su http://127.0.0.1:8080")
})